import { useState } from "react";
import Forms from "./Forms";
import TodoList from "./TodoList";
import Footer from "./Footer";

export default function Todo() {
  const [todos, setTodos] = useState([]);
  const completedCount = todos.filter((todo)=>todo.done).length;
  const totalCount = todos.length;
  return (
    <div>
      <Forms todos={todos} setTodos={setTodos} />
      <TodoList todos = {todos} setTodos = {setTodos}/>
      <Footer completedCount={completedCount} totalCount={totalCount}/>
    </div>
  );
}
//We didn't put todos and setTodos in forms coz
//if we put it there todoList can't access it, so we put that in nearest parent so both form and todolist
//can access it
//and we passed it as props to forms instead of creating it as a state in there