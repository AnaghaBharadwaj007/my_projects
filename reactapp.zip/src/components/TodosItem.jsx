import style from "./todoitem.module.css";
export default function TodosItem({ item, todos, setTodos }) {
  function handleDelete(item) {
    setTodos(todos.filter((todo) => todo !== item));
  }
  function handleClick(name) {
    const newTodos = todos.map((todo) =>
      todo.name === name ? { ...todo, done: !todo.done } : todo
    );
    setTodos(newTodos);
  }

  const classname = item.done ? style.completed : "";
  return (
    <div className={style.item}>
      <div className={style.itemName}>
        <span className={classname} onClick={() => handleClick(item.name)}>{item.name}</span>
        <button onClick={() => handleDelete(item)} className={style.button}>
          X
        </button>
      </div>

      <hr className={style.line} />
    </div>
  );
}
//pass the todo and setTodo from parent component up until here, and use filter to update todos using setTodos
