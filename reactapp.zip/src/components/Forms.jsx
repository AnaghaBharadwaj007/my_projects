import { useState } from "react";
import styles from "./forms.module.css";
export default function Forms({ todos, setTodos }) {
  const [todo, setTodo] = useState({name:"", done:false});
  function handleSubmit(e) {
    e.preventDefault();
    setTodos([...todos, todo]);
    setTodo({name:"", done:false});
  }
  return (
    <div>
      <form className={styles.todoform} onSubmit={handleSubmit}>
        <label>
          <input 
            className={styles.modernInput}
            type="text"
            placeholder="Enter todo item..."
            value={todo.name}
            onChange={(e) => setTodo({name:e.target.value, done:false})}
          />
        </label>
        <button className={styles.modernButton} type="submit">Add</button>
      </form>
    </div>
  );
}
